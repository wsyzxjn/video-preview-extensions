console.log("[Video Preview] Content script loaded");const l=new WeakSet;function c(){if(window.location.hostname.includes("youtube.com")||window.location.hostname.includes("youtu.be")){console.log("[Video Preview] YouTube is disabled due to Web Store policies.");return}new MutationObserver(e=>{e.forEach(n=>{n.addedNodes.forEach(o=>{o instanceof HTMLElement&&(o.tagName==="VIDEO"?i(o):o.querySelectorAll("video").forEach(i))})})}).observe(document.body,{childList:!0,subtree:!0}),document.querySelectorAll("video").forEach(i)}function i(t){if(l.has(t))return;l.add(t);const e=document.createElement("div");e.style.position="absolute",e.style.top="10px",e.style.right="10px",e.style.zIndex="99999",e.style.pointerEvents="auto";const n=e.attachShadow({mode:"open"}),o=document.createElement("button");o.innerText="生成预览 ⇲";const s=document.createElement("style");s.textContent=`
    button {
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(4px);
      border: 1px solid rgba(255, 255, 255, 0.2);
      color: white;
      padding: 6px 12px;
      border-radius: 8px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 12px;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      gap: 4px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    button:hover {
      background: rgba(255, 255, 255, 0.9);
      color: black;
      transform: translateY(-1px);
    }
  `,o.onclick=a=>{a.preventDefault(),a.stopPropagation(),d(t)},n.appendChild(s),n.appendChild(o);const r=t.parentElement;r&&(window.getComputedStyle(r).position==="static"&&(r.style.position="relative"),r.appendChild(e))}function d(t){let e=t.currentSrc||t.src;e&&chrome.runtime.sendMessage({type:"OPEN_PREVIEW",url:e})}document.body?c():window.addEventListener("DOMContentLoaded",c);
